<?php 
require_once("../../../conexao.php");
$tabela = 'cursos_pacotes';

$id = $_POST['id'];
$id = (int) $id;

if ($id > 0) {
	$stmt = $pdo->prepare("DELETE FROM $tabela WHERE id = ?");
	$stmt->execute([$id]);
}

echo 'Excluído com Sucesso';

?>

