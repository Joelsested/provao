<?php
require_once("../../../conexao.php");
require_once(__DIR__ . '/../../aluno_context.php');
$tabela = 'aulas';
@session_start();
$id_aluno = isset($_SESSION['id']) ? (int) $_SESSION['id'] : 0;
if ($id_aluno <= 0 && isset($_POST['id_usu'])) {
  $id_aluno = (int) $_POST['id_usu'];
}

$id_do_curso_pag = (int) ($_POST['id'] ?? 0);
$id_mat = (int) ($_POST['id_mat'] ?? 0);
$alunoContextoIds = aluno_context_ids($pdo);

function montarUrlApostila($arquivo, $urlSistema)
{
  $arquivo = trim((string) $arquivo);
  if ($arquivo === '') {
    return '';
  }
  if (preg_match('#^https?://#i', $arquivo)) {
    return $arquivo;
  }
  return rtrim($urlSistema, '/') . '/sistema/painel-aluno/paginas/cursos/abrir-apostila.php?arquivo=' . rawurlencode($arquivo);
}

// Usa a matricula clicada como fonte de verdade para evitar divergencia no id_curso vindo do front
$paramsMatricula = [':id' => $id_mat];
$whereAlunoMatricula = aluno_context_bind_in('aluno', $alunoContextoIds, $paramsMatricula, 'aluno_mat');
$query_m = $pdo->prepare("SELECT * FROM matriculas WHERE id = :id AND {$whereAlunoMatricula} LIMIT 1");
$query_m->execute($paramsMatricula);
$matricula = $query_m->fetch(PDO::FETCH_ASSOC);

if (!$matricula && $id_do_curso_pag > 0) {
  // fallback para fluxos antigos
  $paramsFallback = [':curso' => $id_do_curso_pag];
  $whereAlunoFallback = aluno_context_bind_in('aluno', $alunoContextoIds, $paramsFallback, 'aluno_fb');
  $query_m = $pdo->prepare("SELECT * FROM matriculas WHERE id_curso = :curso AND {$whereAlunoFallback} AND status != 'Aguardando' ORDER BY id desc LIMIT 1");
  $query_m->execute($paramsFallback);
  $matricula = $query_m->fetch(PDO::FETCH_ASSOC);
}

if (!$matricula || ($matricula['status'] ?? '') === 'Aguardando') {
  @error_log("LISTAR_AULAS_BLOQUEADO usuario={$id_aluno} curso_post={$id_do_curso_pag} id_mat={$id_mat} sessao=" . session_id());
  echo 'Você não está matriculado neste curso!';
  exit();
}

$id_do_curso_pag = (int) $matricula['id_curso'];
$total_aulas_conc = (int) $matricula['aulas_concluidas'];


$query_m = $pdo->prepare("SELECT * FROM cursos WHERE id = :id");
$query_m->execute(['id' => $id_do_curso_pag]);
$res_m = $query_m->fetchAll(PDO::FETCH_ASSOC);
$link_arquivo = $res_m[0]['arquivo'];


echo '<a href="' . $link_arquivo . '" target="_blank" class="cor-aula link-aula"><p class="titulo-curso"><small><img src="img/rar.png" width="20px" style="margin-right:3px"><span>Arquivos do Curso</span></small></p><hr style="margin:8px"></a>';


$query_m = $pdo->prepare("SELECT * FROM sessao WHERE curso = :curso ORDER BY id asc");
$query_m->execute(['curso' => $id_do_curso_pag]);
$res_m = $query_m->fetchAll(PDO::FETCH_ASSOC);
$total_reg_m = @count($res_m);
if ($total_reg_m > 0) {
  $primeira_sessao = $res_m[0]['id'];
  for ($i_m = 0; $i_m < $total_reg_m; $i_m++) {
    foreach ($res_m[$i_m] as $key => $value) {
    }
    $sessao = $res_m[$i_m]['id'];
    $nome_sessao = $res_m[$i_m]['nome'];


    echo '<b><p class="titulo-curso"><small>' . $nome_sessao . '</small></p></b>';



    $query = $pdo->prepare("SELECT * FROM aulas WHERE curso = :curso AND sessao = :sessao ORDER BY num_aula asc");
    $query->execute(['curso' => $id_do_curso_pag, 'sessao' => $sessao]);
    $res = $query->fetchAll(PDO::FETCH_ASSOC);
    $total_reg = @count($res);

    if ($total_reg > 0) {

      for ($i = 0; $i < $total_reg; $i++) {
        foreach ($res[$i] as $key => $value) {
        }
        $id_aula = $res[$i]['id'];
        $nome_aula = $res[$i]['nome'];
        $num_aula = $res[$i]['num_aula'];
        $sessao_aula = $res[$i]['sessao'];
        $link = $res[$i]['link'];
        $seq_aula = $res[$i]['sequencia_aula'];
        $apostila = $res[$i]['apostila'];
        $url_apostila = montarUrlApostila($apostila, $url_sistema);



        if ($apostila == '') {
          $esconder = 'ocultar';

        } else {
          $esconder = '';
        }

        if ($seq_aula <= $total_aulas_conc) {
          $cor_aula = 'cor-aula';
          $ocultar_link = '';
          $ocultar_span = 'ocultar';
        } else {
          $cor_aula = 'text-muted';
          $ocultar_link = 'ocultar';
          $ocultar_span = '';
          $esconder = 'ocultar';
        }




        echo <<<HTML
 				<p style="margin-bottom: 3px">
 				<a href="#" onclick="abrirAula('{$id_aula}', 'aula', '$nome_sessao')" title="Ver Aula" class="link-aula {$ocultar_link}">
				<small>
				<i class="fa fa-video-camera {$cor_aula}" style="margin-right: 2px"></i>
				<span class="{$cor_aula}">Aula {$num_aula} - {$nome_aula}</span>
				</small>
				</a>
					<button class="{$esconder}" type="button" onclick='verApostila("{$url_apostila}")' style="margin-left: 10px;">
          <i class="fa  fa-file-pdf-o" style="display: inline-block;" title="apostila"></i>
        </button>
				<span class="{$ocultar_span}">
				<small>
				<i class="fa fa-video-camera {$cor_aula}" style="margin-right: 2px"></i>
				<span class="{$cor_aula}">Aula {$num_aula} - {$nome_aula}</span>
				<br></small>
				</span>

				</p>
HTML;


      }


    } else {
      echo '<span class="neutra">Nenhuma aula Cadastrada</span>';
    }

    echo '<hr>';

  }



} else {



  $query = $pdo->prepare("SELECT * FROM aulas WHERE curso = :curso ORDER BY num_aula asc");
  $query->execute(['curso' => $id_do_curso_pag]);
  $res = $query->fetchAll(PDO::FETCH_ASSOC);
  $total_reg = @count($res);

  if ($total_reg > 0) {

    for ($i = 0; $i < $total_reg; $i++) {
      foreach ($res[$i] as $key => $value) {
      }
      $id_aula = $res[$i]['id'];
      $nome_aula = $res[$i]['nome'];
      $num_aula = $res[$i]['num_aula'];
      $link = $res[$i]['link'];
      $apostila = $res[$i]['apostila'];
      $url_apostila = montarUrlApostila($apostila, $url_sistema);



      if ($apostila == '') {
        $esconder = 'ocultar';

      } else {
        $esconder = '';
      }

      if ($num_aula <= $total_aulas_conc) {
        $cor_aula = 'cor-aula';
        $ocultar_link = '';
        $ocultar_span = 'ocultar';



      } else {
        $cor_aula = 'text-muted';
        $ocultar_link = 'ocultar';
        $ocultar_span = '';

        $esconder = 'ocultar';


      }

      echo <<<HTML
				<p style="margin-bottom: 3px">

 				<a href="#" onclick="abrirAula('{$id_aula}', 'aula', '')" title="Ver Aula" class="link-aula {$ocultar_link}">
				<small>
				<i class="fa fa-video-camera {$cor_aula}" style="margin-right: 2px"></i>
				<span class="{$cor_aula}">Aula {$num_aula} - {$nome_aula}</span>
				</small>
				</a>
				<!-- <a class="{$esconder}" href="$url_sistema/sistema/painel-admin/img/arquivos/$apostila" target="_blank" ><i class="fa  fa-file-pdf-o" style="display: inline-block;" title="apostila"></i></a> -->
				<!-- <a class="{$esconder}" href="https://google.com" target="_blank" ><i class="fa  fa-file-pdf-o" style="display: inline-block;" title="apostila"></i></a> -->
        
        <button class="{$esconder}" type="button" onclick='verApostila("{$url_apostila}")' style="margin-left: 10px;">
        <i class="fa  fa-file-pdf-o" style="display: inline-block;" title="apostila"></i>
        </button>
				<span class="{$ocultar_span}">
				<small>
				<i class="fa fa-video-camera {$cor_aula}" style="margin-right: 2px"></i>
				<span class="{$cor_aula}">Aula {$num_aula} - {$nome_aula}</span>
				<br></small>
				</span>

				</p>
HTML;


    }


  } else {
    echo '<span class="neutra">Nenhuma aula Cadastrada</span>';
  }


}

?>

<script>

  function verApostila(file) {
    if (!file) {
      return;
    }
    var novaAba = window.open(file, '_blank');
    if (!novaAba) {
      window.location.href = file;
    }
  }

</script>

